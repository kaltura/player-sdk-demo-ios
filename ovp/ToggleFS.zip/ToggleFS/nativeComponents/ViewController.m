//
//  ViewController.m
//  nativeComponents
//
//  Created by Eliza Sapir on 15/02/2016.
//  Copyright © 2016 Kaltura. All rights reserved.
//

#import "ViewController.h"
#import <KALTURAPlayerSDK/KPViewController.h>

@interface ViewController () <KPViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIView *playerContainer;
@property (retain, nonatomic) KPViewController *player;
@end

@implementation ViewController {
    KPPlayerConfig *config;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
//    Present view controller - inline view
    self.player.view.frame = (CGRect){CGPointZero, self.playerContainer.frame.size};
    [self.player loadPlayerIntoViewController:self];
    [self.playerContainer addSubview:_player.view];
    self.player.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (KPViewController *)player {
    if (!_player) {
        config = [[KPPlayerConfig alloc] initWithServer:@"http://cdnapi.kaltura.com"
                                               uiConfID:@"32855491"
                                              partnerId:@"1424501"];
        
        config.entryId = @"1_ypo9wae3";
//        [self hideHTMLControls];
        NSString *kAdTagUrl = @"http://pubads.g.doubleclick.net/gampad/ads?sz=400x300&iu=%2F6062%2Fiab_vast_samples&ciu_szs=300x250%2C728x90&impl=s&gdfp_req=1&env=vp&output=xml_vast2&unviewed_position_start=1&url=[referrer_url]&correlator=[timestamp]&cust_params=iab_vast_samples%3Dlinear";
        
        [config addConfigKey:@"doubleClick.plugin" withValue:@"true"];
        [config addConfigKey:@"doubleClick.adTagUrl" withValue:kAdTagUrl];
        _player = [[KPViewController alloc] initWithConfiguration:config];
    }

    return _player;
}

- (void)hideHTMLControls {
    [config addConfigKey:@"controlBarContainer.plugin" withValue:@"false"];
    [config addConfigKey:@"topBarContainer.plugin" withValue:@"false"];
    [config addConfigKey:@"largePlayBtn.plugin" withValue:@"false"];
}

- (void)play {
    [self.player.playerController play];
}

- (void)pause {
    [self.player.playerController pause];
}

- (void)timeScrubberChange:(UISlider*)slider {
    slider.maximumValue =  self.player.playerController.duration;
    self.player.playerController.currentPlaybackTime = slider.value;
}

- (void)kPlayer:(KPViewController *)player playerFullScreenToggled:(BOOL)isFullScreen {
    if (isFullScreen) {
        [self.player sendNotification:@"onOpenFullScreen" withParams:nil];
    } else {
        [self.player sendNotification:@"onCloseFullScreen" withParams:nil];
    }
}

@end
